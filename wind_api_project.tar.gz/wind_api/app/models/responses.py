"""
Pydantic response (outbound) schemas for the Wind Load API.

These models define the exact JSON shape the frontend receives.
FastAPI serializes the engine's dataclass results through these.
"""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field


# ============================================================================
# Shared / Nested Response Components
# ============================================================================


class SharedParameters(BaseModel):
    """Parameters computed once and shared across all procedures."""
    ke: float = Field(..., description="Ground elevation factor Ke (§26.9)")
    kzt: float = Field(..., description="Topographic factor Kzt (§26.8)")
    kd: float = Field(..., description="Directionality factor Kd (Table 26.6-1)")
    G: float = Field(..., description="Gust effect factor G (§26.11)")
    gcpi: float = Field(..., description="Internal pressure coefficient ±GCpi (§26.13)")
    qh_psf: float = Field(..., description="Velocity pressure at mean roof height (psf)")


class WindwardWallPressure(BaseModel):
    """Windward wall pressure at a single elevation."""
    z_ft: float = Field(..., description="Height above ground (ft)")
    kz: float = Field(..., description="Velocity pressure exposure coefficient at z")
    qz_psf: float = Field(..., description="Velocity pressure at z (psf)")
    p_with_neg_gcpi: float = Field(
        ..., description="qz·G·Cp + qh·|GCpi| — positive internal pressure case (psf)"
    )
    p_with_pos_gcpi: float = Field(
        ..., description="qz·G·Cp − qh·|GCpi| — negative internal pressure case (psf)"
    )


# ============================================================================
# Velocity Pressure Response
# ============================================================================


class VelocityPressureAtHeight(BaseModel):
    """qz result at a single elevation z."""
    z_ft: float
    z_eval_ft: float = Field(..., description="Actual z used in Kz (clipped to z_min)")
    kz: float
    kzt: float
    ke: float
    kd: float
    qz_psf: float
    alpha: float = Field(..., description="Exposure power-law exponent α")
    zg_ft: float = Field(..., description="Gradient height zg (ft)")
    z_min_ft: float = Field(..., description="Minimum height z_min (ft)")


class VelocityPressureResponse(BaseModel):
    """Response for POST /calculate/wind/qz"""
    code_version: str
    V_mph: float
    exposure: str
    importance_factor: float
    pressures: list[VelocityPressureAtHeight]


# ============================================================================
# C&C Pressure Response
# ============================================================================


class CCZonePressure(BaseModel):
    """C&C design pressure result for one zone at one effective wind area."""
    zone: str = Field(..., description="C&C zone (1=field, 2=edge, 3=corner, 4=wall, 5=wall corner)")
    eff_wind_area_sf: float = Field(..., description="Effective wind area (sf)")
    gcp_positive: float = Field(..., description="Positive external pressure coefficient GCp(+)")
    gcp_negative: float = Field(..., description="Negative external pressure coefficient GCp(−)")
    p_pos_with_neg_gcpi: float = Field(
        ..., description="qh·[GCp(+) + |GCpi|] — maximum positive pressure (psf)"
    )
    p_pos_with_pos_gcpi: float = Field(
        ..., description="qh·[GCp(+) − |GCpi|] (psf)"
    )
    p_neg_with_neg_gcpi: float = Field(
        ..., description="qh·[GCp(−) + |GCpi|] (psf)"
    )
    p_neg_with_pos_gcpi: float = Field(
        ..., description="qh·[GCp(−) − |GCpi|] — maximum suction (psf)"
    )


class CCPressureResponse(BaseModel):
    """Response for POST /calculate/wind/cc"""
    code_version: str
    procedure_variant: str = Field(..., description="'h_le_60' or 'h_gt_60'")
    angle_range: str
    qh_psf: float
    gcpi: float
    min_pressure_psf: float
    zone_dimension_a_ft: float = Field(..., description="C&C zone dimension 'a' (ft)")
    pressures: list[CCZonePressure]


# ============================================================================
# MWFRS Directional Response
# ============================================================================


class MWFRSDirectionalResponse(BaseModel):
    """Response for POST /calculate/wind/mwfrs/directional"""
    code_version: str
    qh_psf: float
    G: float
    gcpi: float
    L_ft: float
    B_ft: float
    h_ft: float

    cp_windward_wall: float
    cp_leeward_wall: float
    cp_side_wall: float

    windward_wall_profile: list[WindwardWallPressure]

    leeward_wall_pos_psf: float = Field(..., description="Leeward wall with +GCpi (psf)")
    leeward_wall_neg_psf: float = Field(..., description="Leeward wall with −GCpi (psf)")
    side_wall_pos_psf: float
    side_wall_neg_psf: float

    parapet_windward_psf: float
    parapet_leeward_psf: float


# ============================================================================
# MWFRS Low-Rise Response
# ============================================================================


class LowRiseZonePressure(BaseModel):
    """Pressure for a single zone in the low-rise envelope procedure."""
    zone: str
    gcpf: float = Field(..., description="Combined pressure coefficient GCpf from Figure 28.3-1")
    p_with_neg_gcpi: float = Field(..., description="qh·(GCpf + |GCpi|) (psf)")
    p_with_pos_gcpi: float = Field(..., description="qh·(GCpf − |GCpi|) (psf)")


class MWFRSLowRiseResponse(BaseModel):
    """Response for POST /calculate/wind/mwfrs/lowrise"""
    code_version: str
    is_applicable: bool
    inapplicable_reason: str = ""
    qh_psf: float
    gcpi: float
    end_zone_width_ft: float = Field(
        ..., description="End zone width = 2a (ft)"
    )
    case_a: list[LowRiseZonePressure] = Field(
        ..., description="Case A (transverse) zone pressures"
    )
    case_b: list[LowRiseZonePressure] = Field(
        ..., description="Case B (longitudinal) zone pressures"
    )
    parapet_windward_psf: float
    parapet_leeward_psf: float


# ============================================================================
# Full Analysis Response
# ============================================================================


class FullWindAnalysisResponse(BaseModel):
    """Response for POST /calculate/wind/full-analysis"""
    shared: SharedParameters
    mwfrs_directional: MWFRSDirectionalResponse
    mwfrs_lowrise: MWFRSLowRiseResponse
    cc: CCPressureResponse
